# train_test_plot_def
Python package to train, test, evaluate and plot confusion matrices, feature importance for classification problem using default settings of classifiers
